export default [
  require("C:\\users\\shyogesh\\service_workbench\\service-workbench-on-aws\\docs\\node_modules\\remark-admonitions\\styles\\infima.css"),
  require("C:\\users\\shyogesh\\service_workbench\\service-workbench-on-aws\\docs\\node_modules\\remark-admonitions\\styles\\infima.css"),
  require("C:\\users\\shyogesh\\service_workbench\\service-workbench-on-aws\\docs\\node_modules\\remark-admonitions\\styles\\infima.css"),
  require("C:\\users\\shyogesh\\service_workbench\\service-workbench-on-aws\\docs\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\users\\shyogesh\\service_workbench\\service-workbench-on-aws\\docs\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\users\\shyogesh\\service_workbench\\service-workbench-on-aws\\docs\\src\\css\\custom.css"),
];
