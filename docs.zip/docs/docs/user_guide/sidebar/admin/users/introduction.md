---
id: introduction
title: Users Introduction
sidebar_label: Introduction
---

You can manage Users and Roles in the solution from the **Users** page. Users are entities that can access the solution and Roles define the permissions for Users.
