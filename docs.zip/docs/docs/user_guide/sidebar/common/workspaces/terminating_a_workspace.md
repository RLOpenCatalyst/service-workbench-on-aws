---
id: terminating_a_workspace
title: Terminating a Workspace
sidebar_label: Terminating a Workspace
---

When you no longer need a Workspace you can terminate it. Follow these steps to terminate a Workspace:

1. In the portal navigate to the **Workspaces** page using the menu on the left.
2. In the list of Workspaces, find the Workspace that you want to terminate.
3. Click on the **Terminate** button, the Workspace must be in the **Ready** state to terminate it.
