
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';
export default [
{
  path: '/',
  component: ComponentCreator('/','deb'),
  exact: true,
},
{
  path: '/index.original',
  component: ComponentCreator('/index.original','6ef'),
  exact: true,
},
{
  path: '/',
  component: ComponentCreator('/','4aa'),
  
  routes: [
{
  path: '/best_practices/amazon_inspector',
  component: ComponentCreator('/best_practices/amazon_inspector','79a'),
  exact: true,
},
{
  path: '/best_practices/aws_cloudtrail',
  component: ComponentCreator('/best_practices/aws_cloudtrail','02e'),
  exact: true,
},
{
  path: '/best_practices/aws_shield',
  component: ComponentCreator('/best_practices/aws_shield','33d'),
  exact: true,
},
{
  path: '/best_practices/cicd',
  component: ComponentCreator('/best_practices/cicd','be5'),
  exact: true,
},
{
  path: '/best_practices/introduction',
  component: ComponentCreator('/best_practices/introduction','871'),
  exact: true,
},
{
  path: '/best_practices/multiple_deployment_environments',
  component: ComponentCreator('/best_practices/multiple_deployment_environments','3a1'),
  exact: true,
},
{
  path: '/best_practices/rotating_jwt_token',
  component: ComponentCreator('/best_practices/rotating_jwt_token','071'),
  exact: true,
},
{
  path: '/deployment/about_this_guide',
  component: ComponentCreator('/deployment/about_this_guide','10b'),
  exact: true,
},
{
  path: '/deployment/configuration/auth/configuring_auth0',
  component: ComponentCreator('/deployment/configuration/auth/configuring_auth0','2f5'),
  exact: true,
},
{
  path: '/deployment/configuration/auth/configuring_idp',
  component: ComponentCreator('/deployment/configuration/auth/configuring_idp','2ec'),
  exact: true,
},
{
  path: '/deployment/configuration/auth/enabling_ad',
  component: ComponentCreator('/deployment/configuration/auth/enabling_ad','9f9'),
  exact: true,
},
{
  path: '/deployment/deployment_stages',
  component: ComponentCreator('/deployment/deployment_stages','2c9'),
  exact: true,
},
{
  path: '/deployment/deployment/index',
  component: ComponentCreator('/deployment/deployment/index','0b8'),
  exact: true,
},
{
  path: '/deployment/post_deployment/account_structure',
  component: ComponentCreator('/deployment/post_deployment/account_structure','41a'),
  exact: true,
},
{
  path: '/deployment/post_deployment/aws_accounts',
  component: ComponentCreator('/deployment/post_deployment/aws_accounts','2fd'),
  exact: true,
},
{
  path: '/deployment/post_deployment/create_admin_user',
  component: ComponentCreator('/deployment/post_deployment/create_admin_user','dd9'),
  exact: true,
},
{
  path: '/deployment/post_deployment/create_index_project',
  component: ComponentCreator('/deployment/post_deployment/create_index_project','6b8'),
  exact: true,
},
{
  path: '/deployment/post_deployment/import_service_catalog_products',
  component: ComponentCreator('/deployment/post_deployment/import_service_catalog_products','c4f'),
  exact: true,
},
{
  path: '/deployment/post_deployment/index',
  component: ComponentCreator('/deployment/post_deployment/index','15c'),
  exact: true,
},
{
  path: '/deployment/post_deployment/link_aws_account',
  component: ComponentCreator('/deployment/post_deployment/link_aws_account','55a'),
  exact: true,
},
{
  path: '/deployment/post_deployment/logs',
  component: ComponentCreator('/deployment/post_deployment/logs','76d'),
  exact: true,
},
{
  path: '/deployment/pre_deployment/accounts',
  component: ComponentCreator('/deployment/pre_deployment/accounts','95e'),
  exact: true,
},
{
  path: '/deployment/pre_deployment/configuration',
  component: ComponentCreator('/deployment/pre_deployment/configuration','643'),
  exact: true,
},
{
  path: '/deployment/pre_deployment/deployment_instance',
  component: ComponentCreator('/deployment/pre_deployment/deployment_instance','4fe'),
  exact: true,
},
{
  path: '/deployment/pre_deployment/pre_deployment',
  component: ComponentCreator('/deployment/pre_deployment/pre_deployment','d00'),
  exact: true,
},
{
  path: '/deployment/pre_deployment/prereq_commands',
  component: ComponentCreator('/deployment/pre_deployment/prereq_commands','0cd'),
  exact: true,
},
{
  path: '/deployment/pre_deployment/source_code',
  component: ComponentCreator('/deployment/pre_deployment/source_code','817'),
  exact: true,
},
{
  path: '/deployment/redeployment',
  component: ComponentCreator('/deployment/redeployment','989'),
  exact: true,
},
{
  path: '/deployment/reference/aws_services',
  component: ComponentCreator('/deployment/reference/aws_services','910'),
  exact: true,
},
{
  path: '/deployment/reference/iam_role',
  component: ComponentCreator('/deployment/reference/iam_role','5de'),
  exact: true,
},
{
  path: '/deployment/reference/prepare_master_account',
  component: ComponentCreator('/deployment/reference/prepare_master_account','111'),
  exact: true,
},
{
  path: '/deployment/summary',
  component: ComponentCreator('/deployment/summary','0f4'),
  exact: true,
},
{
  path: '/development/introduction',
  component: ComponentCreator('/development/introduction','7b6'),
  exact: true,
},
{
  path: '/installation_guide/architecture',
  component: ComponentCreator('/installation_guide/architecture','bfe'),
  exact: true,
},
{
  path: '/installation_guide/components',
  component: ComponentCreator('/installation_guide/components','0ce'),
  exact: true,
},
{
  path: '/installation_guide/installation/ami-install',
  component: ComponentCreator('/installation_guide/installation/ami-install','6b7'),
  exact: true,
},
{
  path: '/installation_guide/installation/cloud9install',
  component: ComponentCreator('/installation_guide/installation/cloud9install','2e0'),
  exact: true,
},
{
  path: '/installation_guide/installation/ec2install',
  component: ComponentCreator('/installation_guide/installation/ec2install','5e3'),
  exact: true,
},
{
  path: '/installation_guide/installation/pre-installation/conf-settings',
  component: ComponentCreator('/installation_guide/installation/pre-installation/conf-settings','85d'),
  exact: true,
},
{
  path: '/installation_guide/installation/pre-installation/documentation',
  component: ComponentCreator('/installation_guide/installation/pre-installation/documentation','42f'),
  exact: true,
},
{
  path: '/installation_guide/installation/pre-installation/instance-req',
  component: ComponentCreator('/installation_guide/installation/pre-installation/instance-req','53f'),
  exact: true,
},
{
  path: '/installation_guide/installation/pre-installation/overview',
  component: ComponentCreator('/installation_guide/installation/pre-installation/overview','710'),
  exact: true,
},
{
  path: '/installation_guide/installation/pre-installation/software-req',
  component: ComponentCreator('/installation_guide/installation/pre-installation/software-req','492'),
  exact: true,
},
{
  path: '/installation_guide/installation/pre-installation/tool-req',
  component: ComponentCreator('/installation_guide/installation/pre-installation/tool-req','2dd'),
  exact: true,
},
{
  path: '/installation_guide/overview',
  component: ComponentCreator('/installation_guide/overview','612'),
  exact: true,
},
{
  path: '/installation_guide/postupgrade',
  component: ComponentCreator('/installation_guide/postupgrade','890'),
  exact: true,
},
{
  path: '/installation_guide/troubleshooting',
  component: ComponentCreator('/installation_guide/troubleshooting','fa4'),
  exact: true,
},
{
  path: '/installation_guide/uninstall',
  component: ComponentCreator('/installation_guide/uninstall','8ff'),
  exact: true,
},
{
  path: '/installation_guide/upgrading/commandline',
  component: ComponentCreator('/installation_guide/upgrading/commandline','099'),
  exact: true,
},
{
  path: '/installation_guide/upgrading/solutions',
  component: ComponentCreator('/installation_guide/upgrading/solutions','dbc'),
  exact: true,
},
{
  path: '/introduction',
  component: ComponentCreator('/introduction','251'),
  exact: true,
},
{
  path: '/user_guide/account_structure',
  component: ComponentCreator('/user_guide/account_structure','fcb'),
  exact: true,
},
{
  path: '/user_guide/introduction',
  component: ComponentCreator('/user_guide/introduction','006'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/aws_accounts/create_member_account',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/aws_accounts/create_member_account','d32'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/aws_accounts/cross_account_execution_role',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/aws_accounts/cross_account_execution_role','5dc'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/aws_accounts/introduction',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/aws_accounts/introduction','10d'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/aws_accounts/invite_member_account',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/aws_accounts/invite_member_account','9b5'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/aws_accounts/master_role',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/aws_accounts/master_role','a10'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/aws_accounts/set_account_budget',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/aws_accounts/set_account_budget','a8f'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/indexes/create_new_index',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/indexes/create_new_index','d74'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/indexes/introduction',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/indexes/introduction','66a'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/projects/add_user_to_project',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/projects/add_user_to_project','71d'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/projects/create_project',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/projects/create_project','7c6'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/accounts/projects/introduction',
  component: ComponentCreator('/user_guide/sidebar/admin/accounts/projects/introduction','0d4'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/auth/introduction',
  component: ComponentCreator('/user_guide/sidebar/admin/auth/introduction','471'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/users/add_federated_user',
  component: ComponentCreator('/user_guide/sidebar/admin/users/add_federated_user','fcb'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/users/introduction',
  component: ComponentCreator('/user_guide/sidebar/admin/users/introduction','ca6'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/users/user_roles',
  component: ComponentCreator('/user_guide/sidebar/admin/users/user_roles','df8'),
  exact: true,
},
{
  path: '/user_guide/sidebar/admin/workflows/introduction',
  component: ComponentCreator('/user_guide/sidebar/admin/workflows/introduction','733'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/dashboard/introduction',
  component: ComponentCreator('/user_guide/sidebar/common/dashboard/introduction','2bf'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/studies/creating_a_study',
  component: ComponentCreator('/user_guide/sidebar/common/studies/creating_a_study','b7d'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/studies/data_sources',
  component: ComponentCreator('/user_guide/sidebar/common/studies/data_sources','88c'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/studies/introduction',
  component: ComponentCreator('/user_guide/sidebar/common/studies/introduction','4f5'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/studies/sharing_a_study',
  component: ComponentCreator('/user_guide/sidebar/common/studies/sharing_a_study','651'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/studies/studies_page',
  component: ComponentCreator('/user_guide/sidebar/common/studies/studies_page','32c'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/workspaces/accessing_a_workspace',
  component: ComponentCreator('/user_guide/sidebar/common/workspaces/accessing_a_workspace','506'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/workspaces/create_workspace_study',
  component: ComponentCreator('/user_guide/sidebar/common/workspaces/create_workspace_study','426'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/workspaces/introduction',
  component: ComponentCreator('/user_guide/sidebar/common/workspaces/introduction','a70'),
  exact: true,
},
{
  path: '/user_guide/sidebar/common/workspaces/terminating_a_workspace',
  component: ComponentCreator('/user_guide/sidebar/common/workspaces/terminating_a_workspace','04d'),
  exact: true,
},
]
},
{
  path: '*',
  component: ComponentCreator('*')
}
];
