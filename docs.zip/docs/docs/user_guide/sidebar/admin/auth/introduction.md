---
id: introduction
title: Auth Introduction
sidebar_label: Introduction
---

The solution provides the ability to connect to Active Directory as an Identity Provider. The web-based user interface does not provide the ability to add or update these settings. These settings are defined as part of the deployment of the solution.

See the [**Configuring an IDP**](../../../../deployment/configuration/auth/configuring_idp) section for more information.
