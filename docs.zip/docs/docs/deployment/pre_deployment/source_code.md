---
id: source_code
title: Source Code
sidebar_label: Source Code
---

Download the latest source code using the URL, https://github.com/awslabs/service-workbench-on-aws/tags and run the following command:

`curl -o serviceworkbench.zip <provided_url>`

