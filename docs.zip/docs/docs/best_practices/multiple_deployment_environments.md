---
id: multiple_deployment_environments
title: Multiple Deployment Environments
sidebar_label: Multiple Deployment Environments
---

It is recommended that you deploy separate 'Dev', 'Test' and 'Production' environments of this solution. To do this, following the guidance in the [**Initial Deployment**](/deployment/summary) section.

It is also possible to deploy each environments to different AWS accounts for further separation.
